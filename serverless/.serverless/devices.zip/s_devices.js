
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'akshat46',
  applicationName: 'alwaysai',
  appUid: 'YTrdNHfqyRLSsC0vjX',
  orgUid: '7f25ef19-b067-46f8-aa75-92251baa1db1',
  deploymentUid: 'd9c04919-48aa-4635-844f-694c32480759',
  serviceName: 'devices',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'devices-dev-devices', timeout: 6 };

try {
  const userHandler = require('./lambda-functions/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}